$(document).ready(function(){
   
    if ($(window).width() <= 480) {
        
        $('.carousel').carousel({
            interval: 1000 * 3
        });
        
         $("#carouselContent").click(function(){
             $('#carouselContent').attr('data-interval', 'false');
             $('.carousel-control-next-icon, .carousel-control-prev-icon').css('display', 'inline-block');     
         })
        
    }
    
});